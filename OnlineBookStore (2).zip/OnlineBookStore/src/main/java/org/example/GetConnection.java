package org.example;

import java.sql.*;
import java.util.Scanner;

public class GetConnection {
    public static Connection getConnection() {
        Connection con=null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver Loaded successfully...");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Eshop", "root", "SMrenish@123");
            System.out.println("Database Connected Successfully...");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        return con;
    }
        public static Connection getConnection1() {
            Connection conn=null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                System.out.println("Driver Loaded successfully...");
                conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Transcation", "root", "SMrenish@123");
                System.out.println("Database Connected Successfully...");
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            return conn;
        }


    public static void selectQuery(Connection con) {

        try {
            String query = "select * from payment";
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet res = ps.executeQuery();
            System.out.println("query executed");
            System.out.println("list of Books...");
            while (res.next()) {
                System.out.println(res.getInt(1) + " " + res.getString(2) + " " + res.getInt(3));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        System.out.println();

    }

    public static void insertQuery(Connection con) {

        try {
            String query = "insert into employee values(?,?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, 4);
            ps.setString(2, "arun");
            ps.execute();
            System.out.println("inserted new row");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("query wrong");
        }
    }

    public static void updateQuery(Connection con,int id) {

        try {
            String query = "update payment set quantity=? where id=?";
            PreparedStatement ps = con.prepareStatement(query);
            int b=selectQuantity(con,id);
            int c=0;
            if (b>=1){
                c=b-1;
            }
            else {
                deleteQuery(con,id);
                System.out.println("Out of Stock");
            }
            ps.setInt(1,c);
            ps.setInt(2,id);
            ps.execute();
            System.out.println("query executed");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("update query wrong");
        }
    }

    public static void deleteQuery(Connection con,int id) {

        try {
            String query = "delete from payment where id=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, id);
            ps.execute();
            System.out.println("deleted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void columnDetails(Connection con) {
        try {
            String query = "select * from employee";
            Statement stmt = con.createStatement();
            ResultSet res = stmt.executeQuery(query);
            ResultSetMetaData metadata = res.getMetaData();
            int c = metadata.getColumnCount();
            System.out.println("column count: " + metadata.getColumnCount());
            for (int i = 1; i <= c; i++) {
                System.out.println(metadata.getColumnName(i) + " " + metadata.getColumnTypeName(i));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static int selectQuantity(Connection con, int id) {
        int quantity = 0;
        try {
            String query = "SELECT quantity FROM payment WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet res = ps.executeQuery();

            // Process the ResultSet
            while (res.next()) {
                quantity = res.getInt("quantity");
                return quantity;
//                System.out.println("Quantity: " + res.getInt("quantity")); // Retrieve the value of the column
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return quantity;
    }
    public static void newUser(Connection conn) {
        try {
            Scanner sc = new Scanner(System.in);
            String query = "INSERT INTO account (id, name, phone_no, email, dob, password, account) VALUES (?, ?, ?, ?, ? ,? ,?)";
            PreparedStatement ps = conn.prepareStatement(query);
            System.out.print("Enter your id: ");
            int id = sc.nextInt();
            ps.setInt(1, id);
            System.out.print("Enter your Name: ");
            sc.nextLine();
            String name = sc.nextLine();
            ps.setString(2, name);
            System.out.print("Enter your Number: ");
            String number = sc.nextLine();
            ps.setString(3, number);
            System.out.print("Enter your Email: ");
            String email = sc.nextLine();
            ps.setString(4, email);
            System.out.print("Enter your DOB (yyyy-mm-dd): ");
            String dobInput = sc.nextLine();
            java.sql.Date dob = java.sql.Date.valueOf(dobInput);
            ps.setDate(5, dob);
            System.out.print("Enter password:");
            String password=sc.nextLine().toLowerCase();
            System.out.print("Re-enter password:");
            String password1=sc.nextLine().toLowerCase();
            if (password.equals(password1)){
                ps.setString(6,password);
            }
            else {
                System.out.println("not matched password");
            }
            System.out.println("Account Type");
            System.out.println("1.Buyer");
            System.out.println("2.Seller");
            System.out.print("Enter your choice: ");
            int type =sc.nextInt();
            switch (type) {
                case 1: {
                    ps.setString(7, "Buyer");
                    break; // Prevents fall-through
                }
                case 2: {
                    ps.setString(7, "Seller");
                    break; // Prevents fall-through
                }
                default: {
                    // Optionally handle unexpected type values
                    ps.setString(7, "Unknown");
                    break;
                }
            }
            ps.executeUpdate();
            System.out.println("Successfully created Account");
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid date format! Please use yyyy-mm-dd.");
        }
    }
    public static boolean info(Connection conn) {
        try {
            Scanner sc = new Scanner(System.in);
            String query = "SELECT id FROM account WHERE id = ? AND name = ? AND password = ?"; // Modified SQL query
            PreparedStatement ps = conn.prepareStatement(query);

            System.out.print("Enter your ID: ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter your username: ");
            String name = sc.nextLine();
            System.out.print("Enter your password: ");
            String password = sc.nextLine();
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, password);

            // Execute the query
            ResultSet res = ps.executeQuery();

            if (res.next()) {
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return false; // No match found or an error occurred
    }

    public static boolean info1(Connection conn, int id) {
        try {
            // SQL query to retrieve account type using only the ID
            String query = "SELECT account FROM account WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(query);

            ps.setInt(1, id);


            ResultSet res = ps.executeQuery();

            if (res.next()) {
                String accountType = res.getString("account");
                if ("buyer".equalsIgnoreCase(accountType)) {
                    System.out.println("Access granted: Account belongs to a Buyer.");
                    return true; // Allow access for buyers
                } else {
                    System.out.println("Access denied: Account does not belong to a Buyer. Terminating...");
                    System.exit(1); // Terminate the program
                }
            } else {
                System.out.println("No matching account found for the provided ID. Terminating...");
                System.exit(1); // Terminate the program
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            System.exit(1); // Terminate the program on error
        }
        return false;
    }

    public static boolean info2(Connection conn, int id) {
        try {
            // SQL query to retrieve account type using only the ID
            String query = "SELECT account FROM account WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(query);

            ps.setInt(1, id);

            ResultSet res = ps.executeQuery();

            if (res.next()) {
                String accountType = res.getString("account");
                if ("seller".equalsIgnoreCase(accountType)) {
                    System.out.println("Access granted: Account belongs to a Seller.");
                    return true; // Allow access for sellers
                } else {
                    System.out.println("Access denied: Account does not belong to a Seller. Terminating...");
                    System.exit(1); // Terminate the program
                }
            } else {
                System.out.println("No matching account found for the provided ID. Terminating...");
                System.exit(1); // Terminate the program
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            System.exit(1); // Terminate the program on error
        }
        return false; // Access denied or an error occurred
    }




    public static void order(Connection conn,int id){
        String query="select * from account where id=?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet res = ps.executeQuery()) {
                if (!res.isBeforeFirst()) {
                    System.out.println("No account found for the given ID.");
                    return;
                }
                while (res.next()) {
                    System.out.println("Account Details:");
                    System.out.println("ID: " + res.getInt("id"));
                    System.out.println("Name: " + res.getString("name"));
                    System.out.println("Phone No: " + res.getString("phone_no"));
                    System.out.println("Email: " + res.getString("email"));
                    System.out.println("Account Type: " + res.getString("account"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void orderUpdate(Connection conn,int id) {
        try {
            Scanner sc = new Scanner(System.in);

            // Insert Order
            String query = "INSERT INTO orders (customer_id, customer_name, book_name, no_of_quantity, payment_type) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);

            //id
            ps.setInt(1, id);

            sc.nextLine(); // Consume leftover newline
            System.out.print("Your Name: ");
            String name = sc.nextLine();
            ps.setString(2, name);

            System.out.print("Book Name: ");
            String book_name = sc.nextLine();
            ps.setString(3, book_name);

            System.out.print("No_of_Quantity_Required: ");
            int quantity = sc.nextInt();
            ps.setInt(4, quantity);

            System.out.println("Payment Types ");
            System.out.println("1. Credit Card");
            System.out.println("2. Net Banking");
            System.out.println("3. Cash on Delivery");
            System.out.print("Choose Yours: ");
            int type = sc.nextInt();
            switch (type) {
                case 1 -> ps.setString(5, "Credit Card");
                case 2 -> ps.setString(5, "Net Banking");
                case 3 -> ps.setString(5, "Cash on Delivery");
                default -> {
                    System.out.println("Invalid payment type. Defaulting to 'Cash on Delivery'.");
                    ps.setString(5, "Cash on Delivery");
                }
            }

            ps.executeUpdate();
            System.out.println("ORDER PLACED SUCCESSFULLY...");

            // Retrieve Customer ID and Reference ID
            try {
                String query1 = "SELECT customer_id, reference_id FROM orders WHERE customer_id = ?";
                PreparedStatement ps1 = conn.prepareStatement(query1);
                ps1.setInt(1, id); // Set the parameter correctly

                ResultSet res = ps1.executeQuery();
                while (res.next()) {
                    System.out.println("Customer ID: " + res.getInt("customer_id") + " \nReference ID: " + res.getInt("reference_id"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void seller(Connection con, Connection conn, int account_id) {
        Scanner sc = new Scanner(System.in);
        int id = 0; // Read ID
        String bookname = "";
        int price = 0;
        int quantity = 0;

        try {
            // Fetch the maximum ID from the payment table
            String query1 = "select max(id) from payment";
            PreparedStatement ps1 = con.prepareStatement(query1);
            ResultSet res = ps1.executeQuery();
            int i = 0;
            while (res.next()) {
                i = res.getInt(1);
            }

            // Insert into the payment table
            String query = "insert into payment (id, bookname, price, quantity) values (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);

            System.out.print("Start from " + i + ": ");
            id = sc.nextInt();
            ps.setInt(1, id);

            sc.nextLine(); // Consume newline

            System.out.print("Enter Bookname: ");
            bookname = sc.nextLine();
            ps.setString(2, bookname);

            System.out.print("Price: ");
            price = sc.nextInt();
            ps.setInt(3, price);

            System.out.print("Quantity: ");
            quantity = sc.nextInt();
            ps.setInt(4, quantity);

            ps.executeUpdate();
            System.out.println("Data updated...");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            // Prepare SQL queries for history and account details
            String query = "insert into history (customer_id, reference_id, customer_name, book_name, no_of_quantity) values (?, ?, ?, ?, ?)";
            String querySelect = "select id, name from account where id=?";
            String queryReference = "SELECT reference_id FROM orders WHERE customer_id = ? ORDER BY reference_id DESC LIMIT 1";

            PreparedStatement psHistory = conn.prepareStatement(query);
            PreparedStatement psAccount = conn.prepareStatement(querySelect);
            PreparedStatement psOrders = conn.prepareStatement(queryReference);

            psAccount.setInt(1, account_id); // Fetch account details
            psOrders.setInt(1, account_id);  // Fetch reference ID

            ResultSet resAccount = psAccount.executeQuery();
            ResultSet resOrders = psOrders.executeQuery();

            // Fetch account details
            if (resAccount.next()) {
                psHistory.setInt(1, resAccount.getInt("id")); // customer_id
                psHistory.setString(3, resAccount.getString("name")); // customer_name
            }

            // Fetch reference ID
            if (resOrders.next()) {
                psHistory.setInt(2, resOrders.getInt("reference_id")); // reference_id
            }

            // Set bookname and quantity
            psHistory.setString(4, bookname);
            psHistory.setInt(5, quantity);

            // Insert into history table
            psHistory.executeUpdate();
            System.out.println("History updated...");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void historyPrint(Connection conn){
        try {
            Scanner sc=new Scanner(System.in);
            System.out.print("Enter your Reference_id:");
            int ref=sc.nextInt();
            String query="select * from history where reference_id=?";
            PreparedStatement ps=conn.prepareStatement(query);
            ps.setInt(1,ref);
            ResultSet res=ps.executeQuery();
            while (res.next()){
                System.out.println("Customer id:" + res.getInt("customer_id"));
                System.out.println("reference id:" + res.getInt("reference_id"));
                System.out.println("Customer name:" + res.getString("customer_name"));
                System.out.println("book name:" + res.getString("book_name"));
                System.out.println("no_of_quantity:" + res.getInt("no_of_quantity"));
                System.out.println("created at:" + res.getDate("created_at"));
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

//    public static void deleteOrder(Connection conn){
//        try {
//            String query="delete from history where reference_id=?";
//            String query1="delete from orders where reference id=?";
//            conn.prepareStatement();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }

    public static void check(Connection conn) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your id: " );
        int id=sc.nextInt();

        // Use the updated `info` function
        if (info(conn)) {
            System.out.println("Yes, ID exists.");
            order(getConnection1(),id);
        } else {
            System.out.println("ID not found. Exiting...");
            return; // Exit the method if the ID is not found
        }

        boolean isChoosing = true;
        while (isChoosing) {
            // Display the available options
            selectQuery(getConnection()); // Use the passed connection instead of `getConnection`

            System.out.println("1. Buyer");
            System.out.println("2. Seller");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            switch (choice) {
                case 1 -> {
                    info1(getConnection1(),id);
                    selectQuery(getConnection()); // Use the same connection
                    System.out.println("Which book would you like to buy?");
                    System.out.print("Enter the choice: ");
                    int input = sc.nextInt();
                    orderUpdate(getConnection1(),id);
                    updateQuery(getConnection(), input); // Update the record using the passed connection
                }
                case 2 -> {

                    System.out.println("1.Selling");
                    System.out.println("2.History Checking");
                    System.out.print("Enter choices: ");
                    int opt =sc.nextInt();
                          switch (opt){
                              case 1:{
                                  info2(getConnection1(),id);
                                  seller(getConnection(),getConnection1(),id);
                                  break;
                              }
                              case 2:{
                                  historyPrint(getConnection1());
                                  break;
                              }
                              case 3:{
//                                  deleteOrder(getConnection1(),id);
                              }
                              default:{
                                  System.out.println("Invalid Number");
                                  break;
                              }
                          }
                }
                default -> {
                    System.out.println("Invalid choice. Please try again.");
                }
            }

            System.out.print("\nDo you want to continue with Buy/Sell? (yes/no): ");
            sc.nextLine(); // Clear the input buffer after reading an integer
            String continueChoice = sc.nextLine().trim().toLowerCase();
            if (continueChoice.equals("no")) {
                System.out.println("Thank you...");
                isChoosing = false; // Break the loop
            }
        }
    }
}