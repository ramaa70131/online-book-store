//public class SellerData {
//    private int id;
//    private int referenceId;
//    private String name;
//    private String bookName;
//    private int quantity;
//
//    // Constructor
//    public SellerData(int id, int referenceId, String name, String bookName, int quantity) {
//        this.id = id;
//        this.referenceId = referenceId;
//        this.name = name;
//        this.bookName = bookName;
//        this.quantity = quantity;
//    }
//
//    // Getters
//    public int getId() {
//        return id;
//    }
//
//    public int getReferenceId() {
//        return referenceId;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public String getBookName() {
//        return bookName;
//    }
//
//    public int getQuantity() {
//        return quantity;
//    }
//
//    public static SellerData seller(Connection con) {
//        SellerData sellerData = null;
//        try {
//            Scanner sc = new Scanner(System.in);
//
//            // Get max ID from payment table
//            String query1 = "select max(id) from payment";
//            PreparedStatement ps1 = con.prepareStatement(query1);
//            ResultSet res = ps1.executeQuery();
//            int i = 0;
//            while (res.next()) {
//                i = res.getInt(1);
//            }
//
//            // Insert new data into payment table
//            String query = "insert into payment (id, bookname, price, quantity) values (?, ?, ?, ?)";
//            PreparedStatement ps = con.prepareStatement(query);
//
//            System.out.print("Start from " + i + ": ");
//            int id = sc.nextInt(); // Read ID
//            ps.setInt(1, id);
//
//            // Consume leftover newline
//            sc.nextLine();
//
//            System.out.print("Enter Bookname: ");
//            String bookName = sc.nextLine(); // Read bookname
//            ps.setString(2, bookName);
//
//            System.out.print("Price: ");
//            int price = sc.nextInt(); // Read price
//            ps.setInt(3, price);
//
//            System.out.print("Quantity: ");
//            int quantity = sc.nextInt(); // Read quantity
//            ps.setInt(4, quantity);
//
//            ps.executeUpdate();
//            System.out.println("Data updated...");
//
//            // Read additional details for the SellerData object
//            System.out.print("Enter Reference ID: ");
//            int referenceId = sc.nextInt();
//            sc.nextLine(); // Consume newline
//
//            System.out.print("Enter Name: ");
//            String name = sc.nextLine();
//
//            // Create and return the SellerData object
//            sellerData = new SellerData(id, referenceId, name, bookName, quantity);
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return sellerData;
//    }
//    public static void history(Connection conn, SellerData sellerData) {
//        try {
//            String query = "insert into history (customer_id, reference_id, customer_name, book_name, no_of_quantity) values(?,?,?,?,?)";
//            PreparedStatement ps = conn.prepareStatement(query);
//
//            ps.setInt(1, sellerData.getId()); // Customer ID
//            ps.setInt(2, sellerData.getReferenceId()); // Reference ID
//            ps.setString(3, sellerData.getName()); // Customer Name
//            ps.setString(4, sellerData.getBookName()); // Book Name
//            ps.setInt(5, sellerData.getQuantity()); // Quantity
//
//            ps.executeUpdate();
//            System.out.println("History data inserted...");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//    // Setters (if needed)
//}
//
