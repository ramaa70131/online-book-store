public class Bank {
    public static void main(String[] args){
        System.out.println("$$$ WELCOME TO KANAGARAJ BANK $$$");
        new BankUI();
        System.out.println("THANK YOU FOR VISITING...");
    }
}
